//
//  LoadViewController.h
//  Esterel-Alpha
//
//  Created by utilisateur on 10/01/2014.
//
//

#import <UIKit/UIKit.h>

#import "Mission.h"
#import "PaxCargoCell.h"

@interface LoadViewController : UITableViewController <PaxCargoCellDelegate, MissionDelegate>



@end
