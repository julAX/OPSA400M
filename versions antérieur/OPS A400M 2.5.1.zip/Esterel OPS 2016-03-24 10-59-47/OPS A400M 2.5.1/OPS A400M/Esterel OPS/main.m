//
//  main.m
//  Esterel OPS
//
//  Created by utilisateur on 20/02/2014.
//  Copyright (c) 2014 Esterel. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"


// DO NOT TOUCH ! I REPEAT, DO NOT TOUCH!! //



int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
