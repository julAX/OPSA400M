//
//  CTSTimeTableViewCell.m
//  OPS A400M
//
//  Created by richard david on 10/03/2016.
//  Copyright © 2016 CESAM. All rights reserved.
//

#import "CTSTimeTableViewCell.h"

@implementation CTSTimeTableViewCell

@synthesize time1,time2 ,time3,time4, time1Abs,time2Abs,time3Abs,time4Abs;





@end
