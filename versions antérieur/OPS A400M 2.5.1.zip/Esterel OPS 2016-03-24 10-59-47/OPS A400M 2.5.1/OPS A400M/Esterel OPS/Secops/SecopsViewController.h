//
//  ExploitViewController.h
//  Esterel-Alpha
//
//  Created by utilisateur on 11/02/2014.
//
//

#import <UIKit/UIKit.h>

#import <UIKit/UIKit.h>
#import "QuickTextRefEntViewcontroller.h"
#import "MyTextField.h"


@interface SecopsViewController : UITableViewController <UIPopoverControllerDelegate, QuickTextDelegate>



@end


