//
//  CTSTimeOnlyCell.m
//  OPS A400M
//
//  Created by richard david on 11/03/2016.
//  Copyright © 2016 CESAM. All rights reserved.
//

#import "CTSTimeOnlyCell.h"

@implementation CTSTimeOnlyCell

@synthesize time1,time2 ,time3,time4;


@end
