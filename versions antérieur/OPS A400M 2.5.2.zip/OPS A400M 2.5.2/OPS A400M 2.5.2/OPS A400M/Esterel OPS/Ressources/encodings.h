//
//  encodings.h
//  OPS A400M
//
//  Created by richard david on 28/01/2016.
//  Copyright © 2016 CESAM. All rights reserved.
//

#ifndef encodings_h
#define encodings_h

#define alert657 @"4368696320c3a0206c61202e2e2e"
#define alert243 @"4ac3b46e652c20c3a9766964656d6d656e742021"
#define alert378 @"526f756a652c206269656e2073c3bb722021"
#define alert069 @"43544d20363936392c2073c3a97269657573656d656e74203f213f"
#define alert031 @"6f75692e2e2e"

#define frecWithMacInit @"4368696320c3a020426168757421"
#define frecWithRotateMaster @"4368696320c3a0206c6120676c6f726965757365204ac3b46e652c206d6f6e20436f6c6f6e656c21"
#define frecWithGroundMap @"4368696320c3a0206c61204ac3b46e6521"

#endif /* encodings_h */
