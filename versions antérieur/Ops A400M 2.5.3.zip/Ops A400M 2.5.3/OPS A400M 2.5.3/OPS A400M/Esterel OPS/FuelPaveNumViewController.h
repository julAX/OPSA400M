//
//  FuelPaveNumViewController.h
//  OPS A400M
//
//  Created by Lancelot Ribot on 06/01/2016.
//  Copyright © 2016 CESAM. All rights reserved.
//

#import "PaveNumViewController.h"

@interface FuelPaveNumViewController : PaveNumViewController

@end
