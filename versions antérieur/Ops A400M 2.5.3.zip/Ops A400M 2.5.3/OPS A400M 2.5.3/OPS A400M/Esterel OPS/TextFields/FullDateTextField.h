//
//  DateTextField.h
//  Esterel-Alpha
//
//  Created by utilisateur on 08/01/2014.
//
//

#import "MyTextField.h"

@interface FullDateTextField : MyTextField

@property (strong, nonatomic) NSDate *date, *datePlaceholder;

@end
