//
//  LegsViewController.h
//  Esterel-Alpha
//
//  Created by utilisateur on 16/12/13.
//
//

#import <UIKit/UIKit.h>

#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>


@interface LegMasterViewController : UITableViewController <UIAlertViewDelegate, MFMailComposeViewControllerDelegate>

@end
