//
//  CargoOverViewTableViewCell.m
//  OPS A400M
//
//  Created by richard david on 25/01/2016.
//  Copyright © 2016 CESAM. All rights reserved.
//

#import "CargoOverViewTableViewCell.h"

@implementation CargoOverViewTableViewCell

@synthesize benef, poids, type;

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
