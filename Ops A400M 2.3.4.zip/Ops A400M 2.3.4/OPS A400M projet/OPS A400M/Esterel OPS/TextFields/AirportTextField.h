//
//  AirportTextField.h
//  Esterel-Alpha
//
//  Created by utilisateur on 08/01/2014.
//
//

#import "MyTextField.h"
#import "QuickTextViewController.h"

@interface AirportTextField : MyTextField <QuickTextDelegate, UIPopoverControllerDelegate>

@end
