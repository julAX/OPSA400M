//
//  CTSNumberTableViewCell.h
//  OPS A400M
//
//  Created by richard david on 26/01/2016.
//  Copyright © 2016 CESAM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CTSNumberTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UITextField *numberTextField;

@end
