//
//  CrewViewController.h
//  Esterel-Alpha
//
//  Created by utilisateur on 21/01/2014.
//
//

#import <UIKit/UIKit.h>

#import "Mission.h"

@interface CrewViewController : UITableViewController <MissionDelegate>
- (IBAction)copyPrevious: (UIButton *)sender;



@end
